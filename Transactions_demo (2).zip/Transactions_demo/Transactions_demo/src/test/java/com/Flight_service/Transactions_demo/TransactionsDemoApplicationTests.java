package com.Flight_service.Transactions_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
