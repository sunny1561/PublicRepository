package com.webScraping.using_jsoup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsingJsoupApplicationTests {

	@Test
	void contextLoads() {
	}

}
