package com.webScraping.using_jsoup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsingJsoupApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsingJsoupApplication.class, args);
	}

}
