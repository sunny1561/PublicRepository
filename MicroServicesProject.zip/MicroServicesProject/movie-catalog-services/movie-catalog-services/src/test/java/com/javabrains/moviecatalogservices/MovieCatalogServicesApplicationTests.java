package com.javabrains.moviecatalogservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieCatalogServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
