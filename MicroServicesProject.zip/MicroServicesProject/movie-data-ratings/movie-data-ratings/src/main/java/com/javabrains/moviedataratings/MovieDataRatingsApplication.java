package com.javabrains.moviedataratings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieDataRatingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieDataRatingsApplication.class, args);
	}

}
