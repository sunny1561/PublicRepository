package com.javabrains.moviedataratings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieDataRatingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
