package com.javabrains.movieinfoservices.resource;

import com.javabrains.movieinfoservices.Model.Movie;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/movieinfo")
public class MovieinfoController {
    @RequestMapping("/{movieId}")
     public Movie getMovieIfo(@PathVariable("movieId")  String movieId){

        return new Movie(movieId,"12th Fail");
    }


}
